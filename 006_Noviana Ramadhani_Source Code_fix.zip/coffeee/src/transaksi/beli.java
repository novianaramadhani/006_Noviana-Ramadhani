
package transaksi;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import implemen.staff;


public class beli extends javax.swing.JFrame {
    DefaultTableModel table = new DefaultTableModel();

    
    public beli() {
        initComponents();
//        staff st = new staff();
//        kasir1.setText(st.pegawai());
        tb_keranjang.setModel(table);
        table.addColumn("Kode");
        table.addColumn("Rasa");
        table.addColumn("Jenis");
        table.addColumn("Harga");
        table.addColumn("Jumlah");
        table.addColumn("Total_Harga");
    tampilData();
    }
    
    private void tampilData(){
        //untuk mengahapus baris setelah input
        int row = tb_keranjang.getRowCount();
        for(int a = 0 ; a < row ; a++){
            table.removeRow(0);
        }
        
        try{
        String query = "SELECT * FROM `transaksi` ";
        
            Connection connect = Connect.getKoneksi();//memanggil koneksi
            Statement sttmnt = connect.createStatement();//membuat statement
            ResultSet rslt = sttmnt.executeQuery(query);//menjalanakn query
            
            while (rslt.next()){
                //menampung data sementara
                   
                    String kode = rslt.getString("kode_coffee");
                    String rasa = rslt.getString("rasa");
                    String jenis = rslt.getString("jenis");
                    String harga = rslt.getString("harga");
                    String jumlah = rslt.getString("jumlah");
                    String total = rslt.getString("total_harga");
                    
                //masukan semua data kedalam array
                String[] keranjang = {kode,rasa,jenis,harga,jumlah,total};
                //menambahakan baris sesuai dengan data yang tersimpan diarray
                table.addRow(keranjang);
            }
                //mengeset nilai yang ditampung agar muncul di table
                tb_keranjang.setModel(table);
                
            
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    private void clear(){
        txt_kode.setText(null);
        txt_stok.setText(null);
        txt_rasa.setText(null);
        txt_harga.setText(null);
        txt_jenis.setText(null);
        txt_jumlah2.setText(null);
        txt_totalharga.setText(null);
    }    
    
    private void keranjang(){
        String kode = txt_kode.getText();
        String stok = txt_stok.getText();
        String rasa = txt_rasa.getText();
        String jenis = txt_jenis.getText();
        String harga = txt_harga.getText();
        String jumlah = txt_jumlah2.getText();
        String total = txt_totalharga.getText();

        
        try{
        //panggil koneksi
        Connection connect = Connect.getKoneksi();
        //query untuk memasukan data
        String query = "INSERT INTO `transaksi` (`kode_coffee`, `rasa`, `jenis`, `jumlah`, `harga`, `total_harga`)"
                + "VALUES ('"+kode+"', '"+rasa+"', '"+jenis+"', '"+jumlah+"', '"+harga+"', '"+total+"')";
        
            //menyiapkan statement untuk di eksekusi
            PreparedStatement ps = (PreparedStatement) connect.prepareStatement(query);
            ps.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"Data Masuk Ke-Keranjang");
            
        }catch(SQLException | HeadlessException e){
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"Data Gagal Disimpan");
//            e.printStackTrace();
        }finally{
            tampilData();
            clear();
        }
        autosum();
    }
   
    
    
    public void autosum(){
        int total = 0;
        for (int i = 0; i < tb_keranjang.getRowCount();i++){
        int amount = Integer.parseInt((String)tb_keranjang.getValueAt(i, 5));
        total +=amount;
        }
        txt_totalharga2.setText(""+total);
    }
    
    private void stok(){
        Connection connect = Connect.getKoneksi();//memanggil koneksi
        int stok = Integer.parseInt(txt_stok.getText());
        int jumlahbeli = Integer.parseInt(txt_jumlah2.getText());
        
        if(jumlahbeli > stok ){
            JOptionPane.showMessageDialog(null,"Stok tidak tersedia");
            clear();
        }
        if (jumlahbeli >= 1){    
            int sisastok = (stok-jumlahbeli);
               String query = "UPDATE data SET stok = '" +sisastok+ "' WHERE kode_coffee = '" +txt_kode.getText()+ "'" ;
               try{
                   PreparedStatement ps = (PreparedStatement) connect.prepareStatement(query);
                   ps.executeUpdate();
                }catch(SQLException | HeadlessException e){
                   System.out.println(e);
                   JOptionPane.showMessageDialog(null, "");
                }finally{
                   keranjang();
               }
        }else {
            JOptionPane.showMessageDialog(null, "Invalid Input!!");
            }
            
    }
    
    

    private void total(){
        String harga = txt_harga.getText();
        String jumlah = txt_jumlah2.getText();
        
        int hargaa = Integer.parseInt(harga);
        try{
        int jumlahh = Integer.parseInt(jumlah);
        
        int total = hargaa * jumlahh;
        String total_harga = Integer.toString(total);
        
        txt_totalharga.setText(total_harga);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Only Number");
            txt_jumlah2.setText(null);
        }
    }

    
    private void kembalian(){
        int NominalUang = Integer.parseInt(txt_uang.getText());
        int TotalHarga = Integer.parseInt(txt_totalharga2.getText());
            if (NominalUang >= TotalHarga){
                txt_kembalian.setText(Integer.toString(NominalUang - TotalHarga));
                    JOptionPane.showMessageDialog(null, "Transaksi Berhasil!");
                    
            }else {
            JOptionPane.showMessageDialog(null, "Maaf uang tidak cukup");
            }      
            // klo mau pake reset ini bisa langsung tehapus juga tanpa kita klik reset tpi itu klo ga mau pake struk bisa gitu
//        reset(); 
    }
    
    
    private void reset(){
        try{
            String clear = "TRUNCATE `transaksi`";
            Connection connect = Connect.getKoneksi();
            PreparedStatement ps = (PreparedStatement) connect.prepareStatement(clear);
            ps.execute();
//            keranjang();

        }catch(Exception e){
            System.out.println(e);
        }finally{
            tampilData();
            txt_uang.setText(null);
            txt_kembalian.setText(null);
    }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        txt_totalharga = new javax.swing.JTextField();
        txt_jumlah2 = new javax.swing.JTextField();
        Add = new javax.swing.JButton();
        txt_rasa = new javax.swing.JTextField();
        txt_harga = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_keranjang = new javax.swing.JTable();
        txt_totalharga2 = new javax.swing.JTextField();
        txt_uang = new javax.swing.JTextField();
        Bayar = new javax.swing.JButton();
        txt_kembalian = new javax.swing.JTextField();
        Lihat = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        txt_kode = new javax.swing.JTextField();
        txt_jenis = new javax.swing.JTextField();
        txt_stok = new javax.swing.JTextField();
        reset = new javax.swing.JButton();
        kasir1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/beli.png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_totalharga.setEditable(false);
        txt_totalharga.setBackground(java.awt.Color.white);
        txt_totalharga.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_totalharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalhargaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_totalharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 410, 160, 30));

        txt_jumlah2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_jumlah2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jumlah2ActionPerformed(evt);
            }
        });
        txt_jumlah2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_jumlah2KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_jumlah2KeyTyped(evt);
            }
        });
        getContentPane().add(txt_jumlah2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 320, 140, 30));

        Add.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        Add.setText("  ADD");
        Add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddMouseClicked(evt);
            }
        });
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 460, 100, 40));

        txt_rasa.setEditable(false);
        txt_rasa.setBackground(java.awt.Color.white);
        txt_rasa.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_rasa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_rasaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_rasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 190, 190, 30));

        txt_harga.setEditable(false);
        txt_harga.setBackground(java.awt.Color.white);
        txt_harga.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_hargaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 360, 140, 30));

        tb_keranjang.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tb_keranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_keranjang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_keranjangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb_keranjang);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 130, 370, 180));

        txt_totalharga2.setEditable(false);
        txt_totalharga2.setBackground(java.awt.Color.white);
        txt_totalharga2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_totalharga2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_totalharga2.setEnabled(false);
        txt_totalharga2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                txt_totalharga2MouseReleased(evt);
            }
        });
        txt_totalharga2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalharga2ActionPerformed(evt);
            }
        });
        getContentPane().add(txt_totalharga2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 320, 370, 30));

        txt_uang.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_uang.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_uang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_uangActionPerformed(evt);
            }
        });
        txt_uang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_uangKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_uangKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_uangKeyTyped(evt);
            }
        });
        getContentPane().add(txt_uang, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 360, 370, 30));

        Bayar.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        Bayar.setText("  PAYMENT");
        Bayar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BayarMouseClicked(evt);
            }
        });
        Bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BayarActionPerformed(evt);
            }
        });
        getContentPane().add(Bayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 400, 370, -1));

        txt_kembalian.setEditable(false);
        txt_kembalian.setBackground(java.awt.Color.white);
        txt_kembalian.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        txt_kembalian.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_kembalian.setEnabled(false);
        txt_kembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_kembalianActionPerformed(evt);
            }
        });
        getContentPane().add(txt_kembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 460, 360, 30));

        Lihat.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        Lihat.setText("  LIHAT DATA");
        Lihat.setToolTipText("");
        Lihat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LihatMouseClicked(evt);
            }
        });
        Lihat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LihatActionPerformed(evt);
            }
        });
        getContentPane().add(Lihat, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 130, 30));

        jButton4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton4.setText("  LOGOUT");
        jButton4.setToolTipText("");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 510, 100, 40));

        txt_kode.setEditable(false);
        txt_kode.setBackground(java.awt.Color.white);
        txt_kode.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_kode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_kodeActionPerformed(evt);
            }
        });
        getContentPane().add(txt_kode, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, 70, 30));

        txt_jenis.setEditable(false);
        txt_jenis.setBackground(java.awt.Color.white);
        txt_jenis.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_jenis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jenisActionPerformed(evt);
            }
        });
        getContentPane().add(txt_jenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 190, 30));

        txt_stok.setEditable(false);
        txt_stok.setBackground(java.awt.Color.white);
        txt_stok.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_stokActionPerformed(evt);
            }
        });
        getContentPane().add(txt_stok, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 270, 190, 30));

        reset.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        reset.setText("  RESET");
        reset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                resetMouseClicked(evt);
            }
        });
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        getContentPane().add(reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 90, 40));

        kasir1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        kasir1.setText("Self-Service");
        getContentPane().add(kasir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 30, 180, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/beli.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, -10, 830, 590));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_totalhargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalhargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalhargaActionPerformed

    private void txt_jumlah2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jumlah2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jumlah2ActionPerformed

    private void txt_jumlah2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jumlah2KeyReleased
        // TODO add your handling code here:
        total();
    }//GEN-LAST:event_txt_jumlah2KeyReleased

    private void txt_jumlah2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jumlah2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jumlah2KeyTyped

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        
        stok();
    }//GEN-LAST:event_AddActionPerformed

    private void txt_rasaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_rasaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_rasaActionPerformed

    private void txt_hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_hargaActionPerformed

    private void tb_keranjangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_keranjangMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_keranjangMouseClicked

    private void txt_totalharga2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_totalharga2MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalharga2MouseReleased

    private void txt_totalharga2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalharga2ActionPerformed
//        totalnya();
    }//GEN-LAST:event_txt_totalharga2ActionPerformed

    private void txt_uangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_uangActionPerformed
           
    }//GEN-LAST:event_txt_uangActionPerformed

    private void txt_uangKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_uangKeyPressed
        // TODO add your handling code here:

    }//GEN-LAST:event_txt_uangKeyPressed

    private void txt_uangKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_uangKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_uangKeyReleased

    private void txt_uangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_uangKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_uangKeyTyped

    private void BayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BayarActionPerformed
        kembalian();
    }//GEN-LAST:event_BayarActionPerformed

    private void txt_kembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_kembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_kembalianActionPerformed

    private void LihatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LihatMouseClicked
        // TODO add your handling code here:
        new data().setVisible(true);
        dispose();
    }//GEN-LAST:event_LihatMouseClicked

    private void LihatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LihatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LihatActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        new welcome ().show();
            this.dispose();

    }//GEN-LAST:event_jButton4ActionPerformed

    private void txt_kodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_kodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_kodeActionPerformed

    private void AddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_AddMouseClicked

    private void BayarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BayarMouseClicked
        kembalian();
    }//GEN-LAST:event_BayarMouseClicked

    private void txt_jenisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jenisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jenisActionPerformed

    private void txt_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_stokActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_stokActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed

    }//GEN-LAST:event_resetActionPerformed

    private void resetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetMouseClicked
        reset();
    }//GEN-LAST:event_resetMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
         @Override
         public void run() {
                new beli().setVisible(true);
           
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Bayar;
    private javax.swing.JButton Lihat;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel kasir1;
    private javax.swing.JButton reset;
    private javax.swing.JTable tb_keranjang;
    public javax.swing.JTextField txt_harga;
    public javax.swing.JTextField txt_jenis;
    public javax.swing.JTextField txt_jumlah2;
    public static javax.swing.JTextField txt_kembalian;
    public javax.swing.JTextField txt_kode;
    public javax.swing.JTextField txt_rasa;
    public javax.swing.JTextField txt_stok;
    public javax.swing.JTextField txt_totalharga;
    public static javax.swing.JTextField txt_totalharga2;
    public static javax.swing.JTextField txt_uang;
    // End of variables declaration//GEN-END:variables
}
