/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implemen;

/**
 *
 * @author HP
 */
public class staff implements bahan{ 
    // Penerapan static dan final
    static void namaPegawai(){
        System.out.println("Admin atas nama: Dalinda");
    }
    final String namaTeknisi(){
        return"Teknisi IT adalah mas budi";
    } 
    //Property
    public String nama;
    public String unit_bagian;
    
    //Getter & Setter

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getUnit_bagian() {
        return unit_bagian;
    }

    public void setUnit_bagian(String unit_bagian) {
        this.unit_bagian = unit_bagian;
    }  

    @Override
    public void komposisi() {
       System.out.println("                     === Review ====                 ");
       System.out.println("Sundae adalah sebuah makanan penutup es krim manis. ");
       System.out.println("1. Terdiri dari satu/lebih skoop ice cream");
       System.out.println("2.  Diberi saus atau sirup ");
       System.out.println("3.  Ditambahkan krim kocok,cery maraschino");
       System.out.println("4.  Serta tambahan buah cery");}
    @Override
    public void tester() {
        System.out.println("Silahkan menikmati tester ice kami");
    }
}
