/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implemen;

/**
 *
 * @author HP
 */

interface alamat{
    public String cabang();
}
public class lokasi implements alamat {
    

    public String cabang(){
        return"Cabang toko di Jl.Juanda";
    }
     
    public String ucapan(){
        return"Halo customer, enjoy your day";
    }
   
    // OVERLOADING
    public String ucapan(String u){
        return"Hallo admin, Manajemen data dengan baik yaa";
    }
    
}
